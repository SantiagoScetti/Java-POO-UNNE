package Punto5;


/**
 * Write a description of class AplicacionFacultad here.
 * 
 * @author santi
 * @version 1.0
 */
public class AplicacionFacultad
{
    
}
